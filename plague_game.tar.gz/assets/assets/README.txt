[그림 파일 넣는 곳]
파일이 있으면 그 그림을 쓰고, 없으면 색깔 도형으로 그립니다. 코드는 고치지 않아도 됩니다.
모든 그림은 투명 배경 PNG.

■ characters/  (캐릭터: 4×4 스프라이트 시트, 16장)
   1줄: 아래(↓)  2줄: 왼쪽(←)  3줄: 오른쪽(→)  4줄: 위(↑)
   각 줄 1~4칸 = 걷기 프레임 (1칸 = 서 있는 모습)
   한 칸 32×32 권장 (64×64 등으로 그려도 자동으로 32×32로 줄어듦)

   player.png     시간여행자(주인공)
   fairy.png      책의 요정 (1줄 4칸만 반복 사용 = 날갯짓)
   hans.png       대장장이 한스
   marta.png      빵집 마르타
   klaus.png      촌장 클라우스
   benedikt.png   신부 베네딕트
   otto.png       경비병 오토
   elsa.png       약초꾼 엘자

■ tiles/  (바닥/벽: 32×32 한 장씩)
   grass.png  풀밭      path.png  흙길
   wall.png   돌담      house.png 집
   water.png  물

※ 줄 순서가 다른 시트를 쓰려면 assets.py의 ROW_DOWN, ROW_LEFT, ROW_RIGHT, ROW_UP 숫자를 바꾸세요.
