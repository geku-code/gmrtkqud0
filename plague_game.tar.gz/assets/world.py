# world.py
# 타일 맵(마을 지도)을 관리하는 파일입니다.
# 맵은 문자열로 그리고, 각 글자가 타일 한 칸을 뜻합니다.

import pygame
from settings import (TILE_SIZE, COLOR_GRASS, COLOR_PATH, COLOR_WALL,
                      COLOR_HOUSE, COLOR_WATER, COLOR_BG)
from assets import load_image
from tiles import TileSet

# ---------------- 맵 데이터 ----------------
# 글자 의미:
#   W = 돌담(벽)      H = 집(벽)      ~ = 물(벽)
#   . = 풀밭          = = 큰길(3칸 폭)  , = 골목길(2칸 폭)
#   P = 플레이어 시작 위치 (큰길 위)
# 큰길 끝 세 곳(북쪽, 서쪽, 동쪽)이 마을 담에 닿는 자리 = 성문 (6부)
# (모든 줄의 길이가 같아야 합니다)
VILLAGE_MAP = [
    "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
    "W................===...................W",
    "W..HHHH...HHHH...===....HHHHH..HHHH....W",
    "W..HHHH...HHHH...===....HHHHH..HHHH....W",
    "W..HHHH...HHHH...===....HHHHH..HHHH....W",
    "W...,,.....,,....===.....,,.....,,.....W",
    "W..,,,,,,,,,,,,,,===,,,,,,,,,,,,,,,,,..W",
    "W..,,,,,,,,,,,,,,===,,,,,,,,,,,,,,,,,..W",
    "W................===...................W",
    "W..~~~~..HHHH....===.....HHHH..........W",
    "W..~~~~..HHHH....===.....HHHH..........W",
    "W........HHHH....===.....HHHH..........W",
    "W.........,,.....===......,,...........W",
    "W======================================W",
    "W=================P====================W",
    "W======================================W",
    "WWWWWWWW.........===........WWWWW......W",
    "W......W.........===...HHHH.W...W......W",
    "W................===...HHHH.W..........W",
    "W................===...HHHH.W...W......W",
    "W......W.........===....,,..WWWWW......W",
    "WWWWWWWW.........===....,,.............W",
    "W..,,,,,,,,,,,,,,===,,,,,,,,,,,,,,,,,..W",
    "W..,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,..W",
    "W...HHHH................HHHH...........W",
    "W...HHHH................HHHH.....~~~~..W",
    "W...HHHH................HHHH.....~~~~..W",
    "W......................................W",
    "W......................................W",
    "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
]

# 지나갈 수 없는(충돌하는) 타일 글자들
SOLID_TILES = {"W", "H", "~"}

# 타일 글자 → 색상
TILE_COLORS = {
    "W": COLOR_WALL,
    "H": COLOR_HOUSE,
    "~": COLOR_WATER,
    ".": COLOR_GRASS,
    ",": COLOR_PATH,
    "=": COLOR_PATH,
    "P": COLOR_PATH,   # 시작 위치는 흙길로 표시
}

# 타일 글자 → 그림 파일 (assets/tiles/ 폴더, 32×32 PNG)
# 파일이 없으면 위의 색깔로 그립니다.
# 풀밭(.)과 흙길(, P)은 tiles.py가 여러 그림을 섞고 길 모양을 맞춰서 깝니다.
TILE_FILES = {
    "W": "tiles/wall.png",
    "H": "tiles/house.png",
    "~": "tiles/water.png",
}
PATH_TILES = {",", "=", "P"}   # 흙길로 취급하는 글자


class World:
    """타일 맵을 읽어서 벽 목록을 만들고, 화면에 그려주는 클래스"""

    def __init__(self, map_data=VILLAGE_MAP):
        self.map_data = map_data
        self.rows = len(map_data)
        self.cols = len(map_data[0])
        # 맵 전체 크기(픽셀) - 카메라 계산에 사용
        self.pixel_width = self.cols * TILE_SIZE
        self.pixel_height = self.rows * TILE_SIZE

        self.walls = []                 # 충돌용 벽 사각형 목록
        self.player_start = (TILE_SIZE, TILE_SIZE)  # 기본 시작 위치
        self._load()

        # 타일 그림 불러오기 (없는 것은 None → 색으로 그림)
        self.tile_images = {ch: load_image(path, (TILE_SIZE, TILE_SIZE))
                            for ch, path in TILE_FILES.items()}
        self.tileset = TileSet()
        # 맵은 바뀌지 않으므로 처음에 한 장의 큰 그림으로 미리 그려 둠 → 매 프레임 빠르게 그림
        self.image = pygame.Surface((self.pixel_width, self.pixel_height))
        # 1) 바닥(풀밭, 길 칸 포함)  2) 흙길 덮기  3) 집·담·물
        paths_drawn = False
        if self.tileset.has_grass():
            for row in range(self.rows):
                for col in range(self.cols):
                    self.image.blit(self.tileset.grass_for(col, row),
                                    (col * TILE_SIZE, row * TILE_SIZE))
            paths_drawn = self.tileset.draw_paths(self.image, self.map_data, PATH_TILES)
        for row in range(self.rows):
            for col in range(self.cols):
                ch = self.map_data[row][col]
                if ch in SOLID_TILES or not self.tileset.has_grass() or                         (ch in PATH_TILES and not paths_drawn):
                    self._draw_tile(self.image, col, row)

    def _load(self):
        """맵 문자열을 한 칸씩 읽어서 벽과 시작 위치를 찾습니다."""
        for row, line in enumerate(self.map_data):
            for col, ch in enumerate(line):
                x, y = col * TILE_SIZE, row * TILE_SIZE
                if ch in SOLID_TILES:
                    self.walls.append(pygame.Rect(x, y, TILE_SIZE, TILE_SIZE))
                elif ch == "P":
                    # 타일의 가운데를 시작 위치로 사용
                    self.player_start = (x + TILE_SIZE // 2, y + TILE_SIZE // 2)

    def _draw_tile(self, surface, col, row):
        """타일 한 칸을 그림 또는 색깔로 그립니다. (그림이 없는 타일용)"""
        ch = self.map_data[row][col]
        rect = pygame.Rect(col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE)
        image = self.tile_images.get(ch)   # 집·담·물 그림 (없으면 색깔)
        if image:
            surface.blit(image, rect)
            return
        color = TILE_COLORS.get(ch, COLOR_GRASS)
        pygame.draw.rect(surface, color, rect)
        # 벽 타일에는 테두리를 그려서 구분이 잘 되게 함
        if ch in SOLID_TILES:
            darker = tuple(max(0, c - 30) for c in color)
            pygame.draw.rect(surface, darker, rect, 2)

    def draw(self, surface, camera):
        """미리 그려 둔 맵 그림에서 화면에 보이는 부분만 옮겨 그립니다. camera = 카메라 왼쪽 위 좌표"""
        surface.fill(COLOR_BG)
        cam_x, cam_y = camera
        surface.blit(self.image, (-cam_x, -cam_y))
